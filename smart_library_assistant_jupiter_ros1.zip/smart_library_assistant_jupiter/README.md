# Smart Library Assistant for Jupiter Robot - ROS1 Offline

This is a complete ROS1 Python package for a friendly library assistant robot.
It is designed for a Jupiter Robot-style setup with camera, microphone, speaker, and ROS1.
It does not use internet APIs at runtime.

## What it does

1. Camera detects someone in front of the robot.
2. Robot says: `Hello, do you need help?`
3. User asks a short question by microphone or by ROS text topic.
4. Robot answers using local rules from `config/library.yaml`.
5. Robot returns to idle when the user leaves or says `bye`.

Example questions:

- `Where is AI book?`
- `Library hours?`
- `Help me`
- `Where are computers?`
- `Where is the printer?`

## Package layout

```text
smart_library_assistant/
├── CMakeLists.txt
├── package.xml
├── requirements.txt
├── README.md
├── config/
│   └── library.yaml
├── launch/
│   ├── assistant.launch
│   ├── jupiter.launch
│   ├── terminal_demo.launch
│   └── topic_input_demo.launch
├── scripts/
│   ├── smart_library_assistant_node
│   ├── smart_library_diagnostics
│   └── text_client
└── tools/
    ├── install_dependencies_ubuntu_noetic.sh
    └── fix_permissions.sh
```

## Install

Copy the folder into your catkin workspace:

```bash
cd ~/catkin_ws/src
unzip /path/to/smart_library_assistant_jupiter_ros1.zip
cd smart_library_assistant
./tools/fix_permissions.sh
./tools/install_dependencies_ubuntu_noetic.sh

cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

Check that ROS can find the package:

```bash
rospack find smart_library_assistant
rosrun smart_library_assistant smart_library_diagnostics
```

## First run on Jupiter Robot

Start your Jupiter robot base/camera/audio drivers first, then run:

```bash
roslaunch smart_library_assistant jupiter.launch
```

The launcher defaults to:

- `camera_mode:=auto`
- `input_mode:=sphinx`
- `voice_enabled:=true`
- `presence_mode:=motion`

## Find the camera topic

Run:

```bash
rostopic list
rosrun smart_library_assistant smart_library_diagnostics
```

Look for a topic of type `sensor_msgs/Image`, for example:

```text
/camera/rgb/image_raw
/camera/color/image_raw
/usb_cam/image_raw
```

Then launch with the exact topic:

```bash
roslaunch smart_library_assistant jupiter.launch camera_mode:=topic image_topic:=/camera/rgb/image_raw
```

If the robot camera is exposed as `/dev/video0` instead of a ROS topic:

```bash
roslaunch smart_library_assistant jupiter.launch camera_mode:=webcam camera_index:=0
```

## Find the microphone index

Run:

```bash
rosrun smart_library_assistant smart_library_diagnostics
```

If it prints microphone indexes, launch with one:

```bash
roslaunch smart_library_assistant jupiter.launch mic_device_index:=1
```

If the default microphone works, keep:

```bash
mic_device_index:=-1
```

## Test without real microphone

If speech recognition is bad or the robot audio driver is not ready, do not block your demo. Use topic input:

Terminal 1:

```bash
roslaunch smart_library_assistant topic_input_demo.launch
```

Terminal 2:

```bash
rosrun smart_library_assistant text_client "where is AI book"
rosrun smart_library_assistant text_client "library hours"
rosrun smart_library_assistant text_client "bye"
```

## Safe fallback demo

This uses terminal input and simulated presence fallback if the camera is not available:

```bash
roslaunch smart_library_assistant terminal_demo.launch
```

## Useful ROS topics

The node publishes:

```text
/smart_library_assistant/person_present   std_msgs/Bool
/smart_library_assistant/status           std_msgs/String
/smart_library_assistant/recognized_text  std_msgs/String
/smart_library_assistant/response         std_msgs/String
```

You can inspect them with:

```bash
rostopic echo /smart_library_assistant/status
rostopic echo /smart_library_assistant/response
```

## Important reality check

PocketSphinx is fully offline, but it is not as accurate as cloud speech recognition or a large offline Whisper/Vosk model. For a class demo, keep the command set short and speak clearly:

- `Where is AI book?`
- `Library hours?`
- `Help me`
- `Where are computers?`
- `Bye`

If your Jupiter Robot already has its own speech recognition module, use `input_mode:=topic` and publish recognized text to `/speech_text`. That will be more stable than forcing PocketSphinx to handle everything.

## Common fixes

### ROS cannot locate the node

Run:

```bash
cd ~/catkin_ws/src/smart_library_assistant
./tools/fix_permissions.sh
cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

### No camera detected

Run:

```bash
rostopic list
rosrun smart_library_assistant smart_library_diagnostics
```

Then pass the exact image topic:

```bash
roslaunch smart_library_assistant jupiter.launch camera_mode:=topic image_topic:=/exact/topic/name
```

### No microphone detected

Run:

```bash
arecord -l
rosrun smart_library_assistant smart_library_diagnostics
```

Then launch with the correct index:

```bash
roslaunch smart_library_assistant jupiter.launch mic_device_index:=0
```

### Running through WSL

If the robot camera or microphone is a USB device connected to Windows, WSL2 may not see it automatically. You must expose the USB device to WSL with `usbipd` or run the node directly on the robot Linux system instead.

## Edit answers

Open:

```bash
roscd smart_library_assistant
nano config/library.yaml
```

Change sections and responses to match the real library.
