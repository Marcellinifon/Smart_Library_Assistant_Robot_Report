#!/usr/bin/env bash
set -euo pipefail
chmod +x scripts/smart_library_assistant_node scripts/smart_library_diagnostics scripts/text_client
chmod +x tools/install_dependencies_ubuntu_noetic.sh tools/fix_permissions.sh
