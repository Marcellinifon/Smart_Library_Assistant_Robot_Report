#!/usr/bin/env bash
set -euo pipefail

sudo apt update
sudo apt install -y \
  ros-noetic-rospy \
  ros-noetic-std-msgs \
  ros-noetic-sensor-msgs \
  ros-noetic-cv-bridge \
  python3-opencv \
  python3-yaml \
  python3-pip \
  portaudio19-dev \
  python3-pyaudio \
  espeak \
  espeak-ng \
  alsa-utils

python3 -m pip install --user --upgrade \
  SpeechRecognition \
  pocketsphinx \
  pyttsx3

echo "Dependencies installed. Now run: cd ~/catkin_ws && catkin_make && source devel/setup.bash"
